#include "mod/MyMod.h"
#include <pl/Mod.hpp>

// PL_REGISTER_MOD hanya mendaftarkan fungsi load/enable/disable/unload
// ke libpreloader.so lewat simbol C (extern "C") – tidak ada std::string
// atau std::function yang diserahkan ke lintas-library.
// Ini AMAN dari crash cross-allocator.
PL_REGISTER_MOD(kangetsu_lyrics::KangetsuLyricsMod,
                kangetsu_lyrics::KangetsuLyricsMod::instance());
