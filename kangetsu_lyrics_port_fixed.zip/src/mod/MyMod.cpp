#include "mod/MyMod.h"

#include <filesystem>
#include <pl/Mod.hpp>

// Engine tidak mengimpor pl/ModMenu.hpp atau pl/Platform.hpp
#include "../lyrics/Engine.hpp"

namespace {
// gLyrics disimpan dalam anonymous namespace – tidak ada simbol yang ter-export
// ke luar library. Flag -fvisibility=hidden di CMakeLists.txt memperkuat ini.
kl::Engine gLyrics;
} // namespace

namespace kangetsu_lyrics {

KangetsuLyricsMod& KangetsuLyricsMod::instance() {
    static KangetsuLyricsMod inst;
    return inst;
}

KangetsuLyricsMod::KangetsuLyricsMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool KangetsuLyricsMod::load() {
    auto& self = getSelf();
    self.getLogger().debug("Loading Kangetsu Lyrics...");

    // Buat direktori data & config jika belum ada
    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create data dir {}: {}",
                               self.getDataDir().string(), ec.message());
        return false;
    }
    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create config dir {}: {}",
                               self.getConfigDir().string(), ec.message());
        return false;
    }

    // Load config
    mConfigFile.emplace();
    if (!mConfigFile->load()) {
        self.getLogger().warn("Failed to load config, using defaults");
        // Jangan return false; lanjut dengan default
    } else {
        mConfig = mConfigFile->value();
    }

    self.getLogger().info("Loaded {} from {}",
                          self.getName(), self.getModDir().string());
    return true;
}

bool KangetsuLyricsMod::enable() {
    auto& self = getSelf();
    self.getLogger().debug("Enabling Kangetsu Lyrics...");

    if (!mConfig.enabled) {
        self.getLogger().info("Kangetsu Lyrics disabled by config");
        return true;
    }

    // Terapkan port & posisi dari config ke Engine sebelum start
    gLyrics.setOption("port",   std::to_string(mConfig.port));
    gLyrics.setOption("x",      std::to_string(mConfig.x));
    gLyrics.setOption("y",      std::to_string(mConfig.y));

    // start() TIDAK memanggil pl::modmenu apapun – aman dari crash
    bool ok = gLyrics.start(
        std::string(self.getId()),
        self.getResourceDir().string(),
        [&self](const std::string& msg) { self.getLogger().info(msg); }
    );
    if (!ok) {
        self.getLogger().error("Engine::start() failed");
        return false;
    }
    self.getLogger().info("Kangetsu Lyrics running on port {}", mConfig.port);
    return true;
}

bool KangetsuLyricsMod::disable() {
    getSelf().getLogger().debug("Disabling Kangetsu Lyrics...");
    gLyrics.stop();
    return true;
}

bool KangetsuLyricsMod::unload() {
    getSelf().getLogger().debug("Unloading Kangetsu Lyrics...");
    mConfigFile.reset();
    return true;
}

} // namespace kangetsu_lyrics
