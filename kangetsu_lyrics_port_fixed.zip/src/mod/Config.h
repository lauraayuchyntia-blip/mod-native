#pragma once
// Config.h – Kangetsu Lyrics port
// Konfigurasi sederhana; port companion app dikelola di Engine::Settings.
#include <string>
#include <string_view>
#include <pl/Config.hpp>

namespace kangetsu_lyrics {

struct ModConfig {
    int  version = 1;
    bool enabled = true;
    int  port    = 19133;   // port companion app Kangetsu
    int  x       = 24;      // posisi HUD (dp dari kiri)
    int  y       = 140;     // posisi HUD (dp dari atas)
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace kangetsu_lyrics

template <> struct pl::config::Schema<kangetsu_lyrics::ModConfig> {
    static constexpr std::string_view title       = "Kangetsu Lyrics Config";
    static constexpr std::string_view description = {};

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version")
            return {.title = "Version", .readOnly = true};
        if (name == "enabled")
            return {.title = "Enabled",
                    .description = "Aktifkan/nonaktifkan tampilan lirik."};
        if (name == "port")
            return {.title = "Companion Port",
                    .description = "Port HTTP companion app Kangetsu (default 19133)."};
        if (name == "x")
            return {.title = "HUD X",
                    .description = "Posisi horizontal overlay (dp)."};
        if (name == "y")
            return {.title = "HUD Y",
                    .description = "Posisi vertikal overlay (dp)."};
        return {};
    }
};
