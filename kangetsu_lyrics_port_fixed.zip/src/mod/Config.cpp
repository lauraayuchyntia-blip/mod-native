#include "mod/Config.h"

namespace kangetsu_lyrics {

nlohmann::json makeDefaultConfigJson() { return pl::config::defaultJson(ModConfig{}); }
nlohmann::json makeConfigSchemaJson()  { return pl::config::schema(ModConfig{}); }

} // namespace kangetsu_lyrics
