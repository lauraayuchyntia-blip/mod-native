#pragma once
// MyMod.h – Kangetsu Lyrics port
// Namespace diubah dari clange_me → kangetsu_lyrics untuk kejelasan.
#include <optional>
#include "mod/Config.h"
#include <pl/Mod.hpp>

namespace kangetsu_lyrics {

class KangetsuLyricsMod {
public:
    static KangetsuLyricsMod& instance();

    KangetsuLyricsMod();

    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    ll::mod::NativeMod& mSelf;
    ModConfig           mConfig;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;
};

} // namespace kangetsu_lyrics
