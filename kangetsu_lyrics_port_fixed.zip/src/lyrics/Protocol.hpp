// Pure C++17, no SDK dependency: parsing of the companion app's plain-text protocol,
// lyric-line lookup and the song clock. Unit-tested on the host (tests/test_protocol.cpp).
//
//   GET /now     ->  key<TAB>value lines: id, title, artist, album, dur, pos, playing, lyrics
//   GET /lyrics  ->  first line "id<TAB>N", then one "startMs<TAB>text" per line
#pragma once
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>

namespace kl {

struct Line { int64_t ms = 0; std::string text; };

struct Now {
    bool valid = false;        // false = companion says nothing is playing / bad reply
    int64_t id = 0;            // changes with every new track
    std::string title, artist, album;
    int64_t durMs = 0, posMs = 0;
    bool playing = false;
    int lyrics = 0;            // 0 = still loading, 1 = synced lyrics ready, 2 = none found
};

inline std::vector<std::string> splitLines(const std::string& s) {
    std::vector<std::string> out; std::string cur;
    for (char c : s) {
        if (c == '\n') { out.push_back(cur); cur.clear(); }
        else if (c != '\r') cur.push_back(c);
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

inline int64_t toInt(const std::string& s) { return std::strtoll(s.c_str(), nullptr, 10); }

inline Now parseNow(const std::string& body) {
    Now n;
    for (const auto& line : splitLines(body)) {
        auto tab = line.find('\t');
        if (tab == std::string::npos) continue;
        const std::string k = line.substr(0, tab), v = line.substr(tab + 1);
        if (k == "id") { n.id = toInt(v); n.valid = true; }
        else if (k == "title") n.title = v;
        else if (k == "artist") n.artist = v;
        else if (k == "album") n.album = v;
        else if (k == "dur") n.durMs = toInt(v);
        else if (k == "pos") n.posMs = toInt(v);
        else if (k == "playing") n.playing = v == "1";
        else if (k == "lyrics") n.lyrics = static_cast<int>(toInt(v));
    }
    return n;
}

/** Returns lines sorted by time. *idOut receives the track id the lyrics belong to (0 if absent). */
inline std::vector<Line> parseLyrics(const std::string& body, int64_t* idOut = nullptr) {
    std::vector<Line> out; int64_t id = 0;
    for (const auto& line : splitLines(body)) {
        auto tab = line.find('\t');
        if (tab == std::string::npos) continue;
        const std::string k = line.substr(0, tab), v = line.substr(tab + 1);
        if (k == "id") { id = toInt(v); continue; }
        char* end = nullptr;
        long long ms = std::strtoll(k.c_str(), &end, 10);
        if (end == k.c_str() || *end != '\0') continue;     // not a timestamp
        out.push_back({ms, v});
    }
    std::stable_sort(out.begin(), out.end(), [](const Line& a, const Line& b) { return a.ms < b.ms; });
    if (idOut) *idOut = id;
    return out;
}

/** Index of the last line whose start <= ms, or -1 before the first line. */
inline int findLine(const std::vector<Line>& lines, int64_t ms) {
    int lo = 0, hi = static_cast<int>(lines.size()) - 1, ans = -1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (lines[mid].ms <= ms) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans;
}

/** Song clock: the companion reports a position; we extrapolate between polls. */
class SongClock {
public:
    using Clock = std::chrono::steady_clock;
    void sync(int64_t posMs, bool playing, Clock::time_point at = Clock::now()) {
        mPos = posMs; mPlaying = playing; mAt = at;
    }
    int64_t now(Clock::time_point at = Clock::now()) const {
        if (!mPlaying) return mPos;
        return mPos + std::chrono::duration_cast<std::chrono::milliseconds>(at - mAt).count();
    }
    bool playing() const { return mPlaying; }
private:
    int64_t mPos = 0; bool mPlaying = false; Clock::time_point mAt = Clock::now();
};

inline std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t"), b = s.find_last_not_of(" \t");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

/** Text to show for line `idx`; blank lyric lines (instrumental gaps) become a music-note row. */
inline std::string displayText(const std::vector<Line>& lines, int idx) {
    if (idx < 0 || idx >= static_cast<int>(lines.size())) return "";
    const std::string t = trim(lines[idx].text);
    return t.empty() ? "\xE2\x99\xAA \xE2\x99\xAA \xE2\x99\xAA" : t;   // ♪ ♪ ♪ (UTF-8)
}

} // namespace kl
