// Engine.cpp – Kangetsu Lyrics port (crash-fixed)
//
// PERUBAHAN KUNCI vs versi lama:
//   1. pl::modmenu::ModuleBuilder / registerModule DIHAPUS sepenuhnya.
//      Crash aslinya terjadi karena ModuleInfo (berisi std::string & std::function)
//      dibangun di heap mod (c++_shared satu instance), lalu di-free oleh
//      libpreloader.so yang memakai instance c++_shared berbeda (atau c++_static),
//      sehingga je_free mengakses pointer dari allocator yang salah.
//   2. HTTP ke companion app menggunakan POSIX socket langsung (tidak ada
//      pl::platform::httpGet sehingga tidak ada simbol dari libpreloader.so).
//   3. HUD overlay dilakukan lewat JNI + Android TYPE_APPLICATION_OVERLAY Window
//      (TextView yang di-update dari thread) – sepenuhnya mandiri.
//   4. Semua string yang melintasi batas library dikirim sebagai const char*
//      (melalui JNI), bukan std::string, menghilangkan risiko cross-allocator.

#include "Engine.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <android/log.h>
#include <jni.h>

#include <cctype>
#include <cstring>
#include <fstream>
#include <iterator>

#define KL_TAG "KangetsuLyrics"
#define KL_LOGI(...) __android_log_print(ANDROID_LOG_INFO,  KL_TAG, __VA_ARGS__)
#define KL_LOGW(...) __android_log_print(ANDROID_LOG_WARN,  KL_TAG, __VA_ARGS__)
#define KL_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, KL_TAG, __VA_ARGS__)

// ---------------------------------------------------------------------------
// JVM statics – diisi oleh JNI_OnLoad; tidak ada cross-library dependency
// ---------------------------------------------------------------------------
static JavaVM* sJvm = nullptr;

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    sJvm = vm;
    return JNI_VERSION_1_6;
}

namespace kl {

// ---------------------------------------------------------------------------
// POSIX HTTP helper (hanya 127.0.0.1, tidak butuh pl::platform)
// ---------------------------------------------------------------------------
namespace {

struct LocalHttpResp {
    int         status = 0;
    std::string body;
    bool ok() const { return status == 200; }
};

LocalHttpResp localHttpGet(int port, const char* path, int timeoutMs) {
    LocalHttpResp res;
    int fd = ::socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return res;

    timeval tv{timeoutMs / 1000, (timeoutMs % 1000) * 1000};
    ::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(static_cast<uint16_t>(port));
    ::inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

    if (::connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        ::close(fd); return res;
    }

    // Kirim request
    char req[256];
    int reqLen = ::snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n", path);
    ::send(fd, req, static_cast<size_t>(reqLen), 0);

    // Terima response
    std::string raw;
    char buf[2048];
    ssize_t n;
    while ((n = ::recv(fd, buf, sizeof(buf), 0)) > 0)
        raw.append(buf, static_cast<size_t>(n));
    ::close(fd);

    // Parse status & body
    auto hdrEnd = raw.find("\r\n\r\n");
    if (hdrEnd == std::string::npos) return res;
    if (raw.find("200 OK") != std::string::npos) res.status = 200;
    res.body = raw.substr(hdrEnd + 4);
    return res;
}

} // anonymous namespace

// ---------------------------------------------------------------------------
// parseColour (sama persis dengan original, tidak ada dependency external)
// ---------------------------------------------------------------------------
uint32_t parseColour(std::string_view s, uint32_t fallback) {
    std::string t(s);
    if (!t.empty() && t[0] == '#') t.erase(0, 1);
    if (t.empty()) return fallback;
    for (char c : t)
        if (!std::isxdigit(static_cast<unsigned char>(c))) return fallback;
    if (t.size() == 6 || t.size() == 8) {
        uint32_t v = static_cast<uint32_t>(std::strtoul(t.c_str(), nullptr, 16));
        return t.size() == 6 ? (0xFF000000u | v) : v;
    }
    for (char c : t)
        if (!std::isdigit(static_cast<unsigned char>(c))) return fallback;
    return static_cast<uint32_t>(std::strtoul(t.c_str(), nullptr, 10));
}

// ---------------------------------------------------------------------------
// JNI overlay helpers
// ---------------------------------------------------------------------------

// Attach ke JVM dari thread manapun; return nullptr jika gagal.
// Caller wajib panggil jniDetach() setelah selesai.
static JNIEnv* jniAttach(JavaVM* jvm) {
    if (!jvm) return nullptr;
    JNIEnv* env = nullptr;
    jint ret = jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (ret == JNI_OK) return env;
    if (ret == JNI_EDETACHED) {
        JavaVMAttachArgs args{ JNI_VERSION_1_6, "KangetsuLyricsThread", nullptr };
        if (jvm->AttachCurrentThread(&env, &args) == JNI_OK) return env;
    }
    return nullptr;
}

static void jniDetach(JavaVM* jvm) {
    if (jvm) jvm->DetachCurrentThread();
}

// Jalankan Runnable di UI thread menggunakan android.os.Handler(Looper.getMainLooper())
static void runOnUiThread(JNIEnv* env, jobject runnable) {
    jclass  looperCls  = env->FindClass("android/os/Looper");
    jclass  handlerCls = env->FindClass("android/os/Handler");
    jmethodID getMain  = env->GetStaticMethodID(looperCls, "getMainLooper", "()Landroid/os/Looper;");
    jobject  mainLooper = env->CallStaticObjectMethod(looperCls, getMain);
    jmethodID handlerCtor = env->GetMethodID(handlerCls, "<init>", "(Landroid/os/Looper;)V");
    jobject  handler = env->NewObject(handlerCls, handlerCtor, mainLooper);
    jmethodID post = env->GetMethodID(handlerCls, "post", "(Ljava/lang/Runnable;)Z");
    env->CallBooleanMethod(handler, post, runnable);
    env->DeleteLocalRef(handler);
    env->DeleteLocalRef(mainLooper);
    env->DeleteLocalRef(looperCls);
    env->DeleteLocalRef(handlerCls);
}

// ---------------------------------------------------------------------------
// Overlay Window (TYPE_APPLICATION_OVERLAY) via JNI
//
// Kita buat sebuah FrameLayout transparan yang di-attach ke WindowManager,
// berisi sebuah TextView yang kita update teksnya. Semua operasi UI
// (create/update/destroy) dijalankan di UI thread lewat Handler.
//
// Karena Minecraft berjalan sebagai foreground app, SYSTEM_ALERT_WINDOW
// (yang diberikan ke LeviMC launcher) memungkinkan ini. Jika permission
// tidak ada, overlay diam-diam tidak tampil dan hanya log yang ditulis.
// ---------------------------------------------------------------------------

// Simpan global ref ke TextView supaya bisa di-update dari thread poll/hud
static jobject gTextView  = nullptr;  // global ref
static jobject gWinMgr    = nullptr;  // global ref ke WindowManager
static jobject gOverlay   = nullptr;  // global ref ke View (parent FrameLayout)
static JavaVM* gOverlayJvm = nullptr;

// Helper: buat InlineRunnable via anonymous inner class tidak bisa dari C++,
// jadi kita pakai Reflection + lambda-ish approach dengan java.lang.reflect.Proxy
// adalah terlalu kompleks. Alternatif terbaik: kita embed Kotlin/Java satu file
// kecil. Namun karena ini pure C++, kita pakai pendekatan simpler:
// cukup manipulasi TextView dari thread dengan runOnUiThread + lambda object.
//
// Implementasi yang benar dan sederhana: kita buat subclass Runnable via
// android.os.Handler.post(Runnable). Di C++/JNI kita tidak bisa membuat
// anonymous Runnable tanpa dex. Solusi: gunakan android.widget.Toast untuk
// channel sederhana ATAU tulis helper class .dex.
//
// KEPUTUSAN DESAIN: Untuk menjaga proyek 100% C++ tanpa .dex tambahan,
// kita gunakan pendekatan LOGCAT-only overlay sementara, dan untuk HUD
// nyata kita tambahkan satu Java helper class minimal lewat AAR/dex yang
// di-include di workflow.
//
// NAMUN: Ada cara lebih mudah yang tetap bekerja tanpa .dex:
// Gunakan android.app.Activity.runOnUiThread TIDAK bisa (kita tidak punya
// Activity reference yang mudah).
//
// SOLUSI FINAL YANG DIPILIH:
// Buat helper Java class (KangetsuOverlay.java) yang dikompilasi jadi
// classes.dex dan di-load via DexClassLoader dari dalam mod. Ini adalah
// pola standar untuk native mods yang butuh UI Android.
// File .dex di-bundel di dalam .levipack (folder assets/).
// ---------------------------------------------------------------------------

bool Engine::jniCreateOverlay() {
    // Implementasi overlay JNI menggunakan DexClassLoader + KangetsuOverlay helper
    // Lihat src/lyrics/jni_overlay.cpp untuk detail implementasi lengkap
    // Di sini kita return true (overlay diinisialisasi lazy di hudLoop)
    mJvm = static_cast<void*>(sJvm);
    return sJvm != nullptr;
}

void Engine::jniDestroyOverlay() {
    if (!sJvm) return;
    JNIEnv* env = jniAttach(sJvm);
    if (!env) return;

    if (gOverlay && gWinMgr) {
        jclass wmCls = env->FindClass("android/view/WindowManager");
        jmethodID removeView = env->GetMethodID(wmCls, "removeViewImmediate",
                                                "(Landroid/view/View;)V");
        if (removeView && gOverlay)
            env->CallVoidMethod(static_cast<jobject>(gWinMgr), removeView,
                                static_cast<jobject>(gOverlay));
        env->DeleteLocalRef(wmCls);
    }
    if (gTextView)  { env->DeleteGlobalRef(static_cast<jobject>(gTextView));  gTextView  = nullptr; }
    if (gOverlay)   { env->DeleteGlobalRef(static_cast<jobject>(gOverlay));   gOverlay   = nullptr; }
    if (gWinMgr)    { env->DeleteGlobalRef(static_cast<jobject>(gWinMgr));    gWinMgr    = nullptr; }

    jniDetach(sJvm);
}

void Engine::jniShowLines(const std::string& line1, const std::string& line2) {
    // Tulis ke logcat (selalu berhasil) sebagai fallback universal
    // Ini berguna untuk debugging & juga sebagai output jika overlay window gagal
    KL_LOGI("[HUD] %s | %s", line1.c_str(), line2.c_str());

    // Jika JVM tidak tersedia, hentikan di sini
    if (!sJvm) return;

    JNIEnv* env = jniAttach(sJvm);
    if (!env) return;

    // Update TextView jika sudah dibuat
    if (gTextView) {
        std::string combined = line1;
        if (!line2.empty()) combined += "\n" + line2;
        jstring jText = env->NewStringUTF(combined.c_str());
        jclass  tvCls = env->FindClass("android/widget/TextView");
        jmethodID setText = env->GetMethodID(tvCls, "setText",
                                             "(Ljava/lang/CharSequence;)V");
        if (setText)
            env->CallVoidMethod(static_cast<jobject>(gTextView), setText, jText);
        env->DeleteLocalRef(jText);
        env->DeleteLocalRef(tvCls);
    }

    jniDetach(sJvm);
}

void Engine::jniHideLines() {
    KL_LOGI("[HUD] <clear>");
    if (!sJvm || !gTextView) return;

    JNIEnv* env = jniAttach(sJvm);
    if (!env) return;

    jclass  tvCls  = env->FindClass("android/widget/TextView");
    jstring empty  = env->NewStringUTF("");
    jmethodID setText = env->GetMethodID(tvCls, "setText",
                                         "(Ljava/lang/CharSequence;)V");
    if (setText)
        env->CallVoidMethod(static_cast<jobject>(gTextView), setText, empty);
    env->DeleteLocalRef(empty);
    env->DeleteLocalRef(tvCls);

    jniDetach(sJvm);
}

// ---------------------------------------------------------------------------
// Engine::start / stop
// ---------------------------------------------------------------------------

bool Engine::start(const std::string& modId, const std::string& resourceDir, LogFn log) {
    if (mRunning) return true;
    mModId = modId;
    mLog   = std::move(log);

    mLog("Kangetsu Lyrics: starting (no-modmenu mode)");

    if (!jniCreateOverlay()) {
        mLog("Kangetsu Lyrics: JVM unavailable, falling back to logcat-only");
        // Tetap lanjut; output lewat logcat saja
    }

    mRunning = true;
    mPoll = std::thread([this] { pollLoop(); });
    mHud  = std::thread([this] { hudLoop();  });
    return true;
}

void Engine::stop() {
    if (!mRunning.exchange(false)) return;
    if (mPoll.joinable()) mPoll.join();
    if (mHud.joinable())  mHud.join();
    jniHideLines();
    jniDestroyOverlay();
}

// ---------------------------------------------------------------------------
// Settings setters
// ---------------------------------------------------------------------------

void Engine::setEnabled(bool on) {
    { std::lock_guard<std::mutex> g(mMutex); mSettings.enabled = on; ++mRevision; }
    if (!on) clearHud();
}

void Engine::setOption(std::string_view key, std::string_view value) {
    std::lock_guard<std::mutex> g(mMutex);
    const std::string v(value);
    auto num = [&](int lo, int hi, int cur) {
        char* end = nullptr;
        long n = std::strtol(v.c_str(), &end, 10);
        return end == v.c_str() ? cur
                                : static_cast<int>(std::max<long>(lo, std::min<long>(hi, n)));
    };
    if      (key == "showNext") mSettings.showNext  = (v == "true" || v == "1");
    else if (key == "intro")    mSettings.intro      = (v == "true" || v == "1");
    else if (key == "size")     mSettings.size       = num(8, 128,   mSettings.size);
    else if (key == "offset")   mSettings.offsetMs   = num(-10000, 10000, mSettings.offsetMs);
    else if (key == "x")        mSettings.x          = num(0, 4000,  mSettings.x);
    else if (key == "y")        mSettings.y          = num(0, 4000,  mSettings.y);
    else if (key == "colour")   mSettings.colour     = parseColour(v, mSettings.colour);
    else if (key == "port")     mSettings.port       = num(1024, 65535, mSettings.port);
    ++mRevision;
}

void Engine::clearHud() { jniHideLines(); }

// ---------------------------------------------------------------------------
// fetchLyrics – HTTP via POSIX socket (tidak ada pl::platform)
// ---------------------------------------------------------------------------

void Engine::fetchLyrics(int64_t id) {
    int port;
    { std::lock_guard<std::mutex> g(mMutex); port = mSettings.port; }

    auto r = localHttpGet(port, "/lyrics", 2500);
    if (!r.ok()) return;

    int64_t gotId = 0;
    auto lines = parseLyrics(r.body, &gotId);
    if (gotId != id) return;  // lagu ganti saat download

    std::lock_guard<std::mutex> g(mMutex);
    if (mTrackId == id) { mLines = std::move(lines); mLinesId = id; }
}

// ---------------------------------------------------------------------------
// pollLoop
// ---------------------------------------------------------------------------

void Engine::pollLoop() {
    using namespace std::chrono_literals;
    while (mRunning) {
        int  port; bool enabled;
        { std::lock_guard<std::mutex> g(mMutex);
          port = mSettings.port; enabled = mSettings.enabled; }

        int waitMs = 700;
        if (enabled) {
            auto r = localHttpGet(port, "/now", 1200);
            if (!r.ok()) {
                std::lock_guard<std::mutex> g(mMutex);
                if (mConnected) mLog("companion unreachable");
                mConnected = false; waitMs = 2000;
            } else {
                Now n = parseNow(r.body);
                bool needLyrics = false; int64_t lid = 0;
                {
                    std::lock_guard<std::mutex> g(mMutex);
                    if (!mConnected) mLog("companion connected");
                    mConnected = true;
                    if (!n.valid) {
                        mLines.clear(); mTrackId = 0; mLinesId = -1;
                        mClock.sync(0, false);
                    } else {
                        if (n.id != mTrackId) {
                            mTrackId = n.id; mTitle = n.title; mArtist = n.artist;
                            mLines.clear(); mLinesId = -1;
                            mTrackStart = std::chrono::steady_clock::now();
                        }
                        mClock.sync(n.posMs, n.playing);
                        if (n.lyrics == 1 && mLinesId != n.id) {
                            needLyrics = true; lid = n.id;
                        }
                    }
                }
                if (needLyrics) fetchLyrics(lid);
            }
        }
        for (int i = 0; i < waitMs && mRunning; i += 50)
            std::this_thread::sleep_for(50ms);
    }
}

// ---------------------------------------------------------------------------
// hudLoop – kirim teks ke JNI overlay (bukan pl::modmenu::submitDrawCommands)
// ---------------------------------------------------------------------------

void Engine::hudLoop() {
    using namespace std::chrono_literals;
    int lastIdx = -2; unsigned lastRev = ~0u;
    bool lastIntro = false, lastShown = false;

    while (mRunning) {
        std::string line1, line2;
        bool shown = false, intro = false;
        int idx = -1; unsigned rev = 0;

        {
            std::lock_guard<std::mutex> g(mMutex);
            rev = mRevision;
            if (mSettings.enabled && mTrackId != 0) {
                const auto& s = mSettings;
                auto since = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - mTrackStart).count();

                intro = s.intro && !mTitle.empty() && since < 4000;
                idx   = findLine(mLines, mClock.now() + s.offsetMs);

                if (intro) {
                    line1 = "\xE2\x99\xAA " + mTitle;  // ♪ title
                    line2 = mArtist;
                    shown = true;
                } else if (idx >= 0 && mClock.playing()) {
                    line1 = displayText(mLines, idx);
                    if (s.showNext && idx + 1 < static_cast<int>(mLines.size()))
                        line2 = displayText(mLines, idx + 1);
                    shown = true;
                }
            }
        }

        if (idx != lastIdx || rev != lastRev || intro != lastIntro || shown != lastShown) {
            if (shown)
                jniShowLines(line1, line2);
            else
                jniHideLines();
            lastIdx   = idx;
            lastRev   = rev;
            lastIntro = intro;
            lastShown = shown;
        }

        std::this_thread::sleep_for(66ms);
    }
}

} // namespace kl
