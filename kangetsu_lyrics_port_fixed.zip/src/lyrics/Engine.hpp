#pragma once
// Engine.hpp – Kangetsu Lyrics port
// TIDAK menyentuh pl::modmenu sama sekali; overlay dilakukan lewat JNI Toast/Window
// sehingga tidak ada cross-ABI struct yang di-pass ke libpreloader.so.
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <vector>
#include "Protocol.hpp"

namespace kl {

struct Settings {
    bool enabled  = true;
    bool showNext = true;
    bool intro    = true;
    int  size     = 28;      // sp
    int  offsetMs = 0;
    int  x        = 24;      // dp
    int  y        = 140;
    uint32_t colour = 0xFFFFFFFFu; // ARGB
    int  port     = 19133;
};

/** Polls companion app, keeps song clock, renders lyrics via JNI overlay.
 *  Tidak bergantung pada pl::modmenu maupun pl::platform. */
class Engine {
public:
    using LogFn = std::function<void(const std::string&)>;

    bool start(const std::string& modId, const std::string& resourceDir, LogFn log);
    void stop();

    // Dipanggil dari thread manapun; aman (mutex-protected)
    void setEnabled(bool on);
    void setOption(std::string_view key, std::string_view value);

private:
    void pollLoop();
    void hudLoop();
    void fetchLyrics(int64_t id);
    void clearHud();

    // --- JNI overlay helpers (didefinisikan di Engine.cpp) ---
    bool jniCreateOverlay();   // buat Window overlay Android
    void jniDestroyOverlay();
    void jniShowLines(const std::string& line1, const std::string& line2);
    void jniHideLines();

    std::string mModId;
    LogFn       mLog;
    std::atomic<bool> mRunning{false};
    std::thread mPoll, mHud;

    std::mutex mMutex;
    Settings   mSettings;
    unsigned   mRevision   = 0;
    int64_t    mTrackId    = 0, mLinesId = -1;
    std::string mTitle, mArtist;
    std::vector<Line> mLines;
    SongClock  mClock;
    bool       mConnected  = false;
    std::chrono::steady_clock::time_point mTrackStart;

    // JNI state – hanya diakses dari constructor/destructor overlay, bukan dari loop
    void* mJvm          = nullptr; // JavaVM*  (disimpan saat JNI_OnLoad)
    void* mOverlayRef   = nullptr; // jobject global ref ke overlay View
};

uint32_t parseColour(std::string_view s, uint32_t fallback);

} // namespace kl
