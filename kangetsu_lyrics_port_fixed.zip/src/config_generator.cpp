// config_generator.cpp – dijalankan di host (bukan Android) untuk generate
// config.json dan config.schema.json dari ModConfig.
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>

#include "mod/Config.h"

int main(int argc, char* argv[]) {
    std::filesystem::path outDir = argc > 1 ? argv[1] : ".";
    std::filesystem::create_directories(outDir);

    {
        std::ofstream f(outDir / "config.json");
        f << kangetsu_lyrics::makeDefaultConfigJson().dump(2) << '\n';
    }
    {
        std::ofstream f(outDir / "config.schema.json");
        f << kangetsu_lyrics::makeConfigSchemaJson().dump(2) << '\n';
    }
    std::cout << "Generated config files in " << outDir << '\n';
    return 0;
}
