cmake_minimum_required(VERSION 3.22)

project(kangetsu_lyrics_port LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# ── Identitas mod ────────────────────────────────────────────────────────────
set(MOD_ID              "kangetsu_lyrics_port" CACHE STRING "Package dir name")
set(MOD_NAME            "Kangetsu Lyrics (port)" CACHE STRING "Display name")
set(MOD_AUTHOR          "clange_me"            CACHE STRING "Author")
set(MOD_VERSION         "0.2.0"                CACHE STRING "Version")
set(MOD_LIBRARY_NAME    "kangetsu_lyrics_port" CACHE STRING "Library name (no lib prefix / .so)")
set(MOD_MINECRAFT_VERSIONS "[]"               CACHE STRING "Raw JSON array")
set(MOD_ICON            ""                     CACHE STRING "Optional icon path")

# ── Dependensi ───────────────────────────────────────────────────────────────
include(FetchContent)

FetchContent_Declare(
    preloader_android
    GIT_REPOSITORY https://github.com/LiteLDev/preloader-android.git
    GIT_TAG        0.2.2
    SOURCE_SUBDIR  cmake/preloader-sdk
)
FetchContent_Declare(
    nlohmann_json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG        v3.11.3
)
FetchContent_Declare(
    boost_pfr
    GIT_REPOSITORY https://github.com/boostorg/pfr.git
    GIT_TAG        boost-1.88.0
)
FetchContent_Declare(
    magic_enum
    GIT_REPOSITORY https://github.com/Neargye/magic_enum.git
    GIT_TAG        v0.9.7
)
FetchContent_Declare(
    fmt
    GIT_REPOSITORY https://github.com/fmtlib/fmt.git
    GIT_TAG        11.2.0
)
set(FMT_DOC     OFF CACHE BOOL "" FORCE)
set(FMT_TEST    OFF CACHE BOOL "" FORCE)
set(FMT_INSTALL OFF CACHE BOOL "" FORCE)

FetchContent_MakeAvailable(
    preloader_android nlohmann_json boost_pfr magic_enum fmt)

FetchContent_GetProperties(preloader_android)
set(LEVI_PRELOADER_INCLUDE_DIR "${preloader_android_SOURCE_DIR}/include")

# ── Build host: config generator saja ───────────────────────────────────────
if(NOT ANDROID)
    set(LEVI_GENERATED_CONFIG_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated-config")

    add_executable(levi_config_generator
        src/config_generator.cpp
        src/mod/Config.cpp
    )
    target_include_directories(levi_config_generator PRIVATE
        src
        "${LEVI_PRELOADER_INCLUDE_DIR}"
    )
    target_compile_definitions(levi_config_generator PRIVATE PL_CONFIG_NO_RUNTIME)
    target_link_libraries(levi_config_generator PRIVATE
        nlohmann_json::nlohmann_json
        Boost::pfr
        magic_enum::magic_enum
    )

    add_custom_target(levi_generate_config
        COMMAND levi_config_generator "${LEVI_GENERATED_CONFIG_DIR}"
        DEPENDS levi_config_generator
        COMMENT "Generating config.json and config.schema.json"
        VERBATIM
    )
    return()
endif()

# ── Validasi ─────────────────────────────────────────────────────────────────
if(NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "arm64-v8a" AND
   NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "armeabi-v7a")
    message(FATAL_ERROR "Unsupported ABI: ${CMAKE_ANDROID_ARCH_ABI}")
endif()

# ── Pastikan ANDROID_STL = c++_shared (tidak boleh c++_static) ───────────────
# c++_static menyebabkan dua runtime STL di memori (satu dari libminecraftpe,
# satu dari mod), allocator berbeda → crash di je_free saat cross-library free.
if(DEFINED ANDROID_STL AND NOT ANDROID_STL STREQUAL "c++_shared")
    message(FATAL_ERROR
        "ANDROID_STL must be c++_shared, got '${ANDROID_STL}'. "
        "Pass -DANDROID_STL=c++_shared to CMake.")
endif()

# ── Preloader ─────────────────────────────────────────────────────────────────
option(LEVI_LINK_PRELOADER
    "Build and link the preloader target instead of leaving SDK symbols for runtime lookup"
    ON)

if(LEVI_LINK_PRELOADER AND NOT TARGET preloader)
    add_subdirectory("${preloader_android_SOURCE_DIR}"
                     "${CMAKE_BINARY_DIR}/_preloader_android")
endif()

if(NOT DEFINED LEVI_PACKAGE_CONFIG_DIR)
    set(LEVI_PACKAGE_CONFIG_DIR "${CMAKE_CURRENT_SOURCE_DIR}/config" CACHE PATH
        "Directory containing config.json and config.schema.json")
endif()
get_filename_component(LEVI_PACKAGE_CONFIG_DIR "${LEVI_PACKAGE_CONFIG_DIR}" ABSOLUTE)
set(LEVI_PACKAGE_CONFIG_JSON   "${LEVI_PACKAGE_CONFIG_DIR}/config.json")
set(LEVI_PACKAGE_CONFIG_SCHEMA "${LEVI_PACKAGE_CONFIG_DIR}/config.schema.json")

if(NOT IS_DIRECTORY "${LEVI_PACKAGE_CONFIG_DIR}")
    message(FATAL_ERROR "LEVI_PACKAGE_CONFIG_DIR is not a directory: ${LEVI_PACKAGE_CONFIG_DIR}")
endif()
if(NOT EXISTS "${LEVI_PACKAGE_CONFIG_JSON}")
    message(FATAL_ERROR "Missing config.json in: ${LEVI_PACKAGE_CONFIG_DIR}")
endif()
if(NOT EXISTS "${LEVI_PACKAGE_CONFIG_SCHEMA}")
    message(FATAL_ERROR "Missing config.schema.json in: ${LEVI_PACKAGE_CONFIG_DIR}")
endif()

# ── Library utama ─────────────────────────────────────────────────────────────
add_library(${MOD_LIBRARY_NAME} SHARED
    src/main.cpp
    src/mod/Config.cpp
    src/mod/MyMod.cpp
    src/lyrics/Engine.cpp
    # Protocol.hpp adalah header-only; tidak perlu .cpp
)

set_target_properties(${MOD_LIBRARY_NAME} PROPERTIES
    OUTPUT_NAME "${MOD_LIBRARY_NAME}"
)

target_include_directories(${MOD_LIBRARY_NAME} PRIVATE
    src
    "${LEVI_PRELOADER_INCLUDE_DIR}"
)

target_compile_options(${MOD_LIBRARY_NAME} PRIVATE
    # Sembunyikan semua simbol C++ internal mod dari libminecraftpe & libpreloader.
    # Ini mencegah tabrakan simbol (terutama vtable, typeinfo, operator new/delete)
    # antar library yang berbeda.
    $<$<COMPILE_LANG_AND_ID:CXX,Clang,GNU>:
        -fvisibility=hidden
        -fvisibility-inlines-hidden
        -ffunction-sections
        -fdata-sections
    >
)

target_link_options(${MOD_LIBRARY_NAME} PRIVATE
    # 16 KB page size (wajib untuk Android 15+)
    "-Wl,-z,max-page-size=16384"
    # Hapus section yang tidak dipakai → binary lebih kecil & lebih aman
    "-Wl,--gc-sections"
)

find_library(log-lib log REQUIRED)
find_library(android-lib android REQUIRED)   # untuk JNI overlay

target_link_libraries(${MOD_LIBRARY_NAME} PRIVATE
    ${log-lib}
    ${android-lib}
    nlohmann_json::nlohmann_json
    Boost::pfr
    magic_enum::magic_enum
    fmt::fmt
)

if(TARGET preloader)
    target_link_libraries(${MOD_LIBRARY_NAME} PRIVATE preloader)
else()
    target_link_options(${MOD_LIBRARY_NAME} PRIVATE
        "-Wl,--unresolved-symbols=ignore-all")
endif()

# ── Strip ─────────────────────────────────────────────────────────────────────
if(NOT CMAKE_STRIP)
    message(FATAL_ERROR "CMAKE_STRIP is required.")
endif()

add_custom_command(TARGET ${MOD_LIBRARY_NAME} POST_BUILD
    COMMAND "${CMAKE_STRIP}" --strip-unneeded "$<TARGET_FILE:${MOD_LIBRARY_NAME}>"
    COMMENT "Stripping ${MOD_LIBRARY_NAME}"
    VERBATIM
)

# ── Package ───────────────────────────────────────────────────────────────────
configure_file(
    "${CMAKE_CURRENT_SOURCE_DIR}/manifest.json.in"
    "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
    @ONLY
)

set(LEVI_PACKAGE_ROOT    "${CMAKE_CURRENT_BINARY_DIR}/package")
set(LEVI_PACKAGE_MOD_DIR "${LEVI_PACKAGE_ROOT}/${MOD_ID}")
set(LEVI_PACKAGE_FILE    "${CMAKE_CURRENT_BINARY_DIR}/${MOD_ID}-${MOD_VERSION}-${CMAKE_ANDROID_ARCH_ABI}.levipack")
set(LEVI_PACKAGE_ICON_COMMAND)
set(LEVI_PACKAGE_CONFIG_COMMAND
    COMMAND "${CMAKE_COMMAND}" -E copy_directory "${LEVI_PACKAGE_CONFIG_DIR}" "${LEVI_PACKAGE_MOD_DIR}/config")

if(NOT MOD_ICON STREQUAL "")
    if(IS_ABSOLUTE "${MOD_ICON}")
        message(FATAL_ERROR "MOD_ICON must be relative")
    endif()
    if(MOD_ICON MATCHES "(^|/)\\.\\.(/|$)")
        message(FATAL_ERROR "MOD_ICON must not contain ..")
    endif()
    set(MOD_ICON_SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/${MOD_ICON}")
    if(NOT EXISTS "${MOD_ICON_SOURCE}")
        message(FATAL_ERROR "MOD_ICON not found: ${MOD_ICON_SOURCE}")
    endif()
    get_filename_component(MOD_ICON_DIR "${MOD_ICON}" DIRECTORY)
    if(NOT MOD_ICON_DIR STREQUAL "")
        list(APPEND LEVI_PACKAGE_ICON_COMMAND
            COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}/${MOD_ICON_DIR}")
    endif()
    list(APPEND LEVI_PACKAGE_ICON_COMMAND
        COMMAND "${CMAKE_COMMAND}" -E copy "${MOD_ICON_SOURCE}" "${LEVI_PACKAGE_MOD_DIR}/${MOD_ICON}")
endif()

add_custom_target(levi_package
    COMMAND "${CMAKE_COMMAND}" -E rm -rf "${LEVI_PACKAGE_ROOT}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}"
    COMMAND "${CMAKE_COMMAND}" -E copy
        "$<TARGET_FILE:${MOD_LIBRARY_NAME}>"
        "${LEVI_PACKAGE_MOD_DIR}/lib${MOD_LIBRARY_NAME}.so"
    COMMAND "${CMAKE_COMMAND}" -E copy
        "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
        "${LEVI_PACKAGE_MOD_DIR}/manifest.json"
    ${LEVI_PACKAGE_ICON_COMMAND}
    ${LEVI_PACKAGE_CONFIG_COMMAND}
    COMMAND "${CMAKE_COMMAND}" -E chdir "${LEVI_PACKAGE_ROOT}"
        "${CMAKE_COMMAND}" -E tar "cf" "${LEVI_PACKAGE_FILE}" --format=zip "${MOD_ID}"
    WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}"
    DEPENDS ${MOD_LIBRARY_NAME}
    COMMENT "Packaging ${MOD_ID} for LeviLauncher"
    VERBATIM
)
